# Protect the Children!
A WordPress plugin to allow the ability to protect child posts/pages of posts/pages that are password protected

This plugin depends on a bundled version of the Modern WordPress framework (http://github.com/Miller-Media/modern-wordpress).

When you are editing a post or page and choose to change the visibility to 'Password Protected', a checkbox with the words 'Password Protect all child posts' will appear above the submit/update button. Check this and all of that post/page's children will be protect as well.