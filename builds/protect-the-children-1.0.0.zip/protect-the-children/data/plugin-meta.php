<?php
return <<<'JSON'
{
    "vendor": "Miller Media",
    "author": "Matt Miller",
    "name": "Protect the Children",
    "namespace": "MillerMedia\\ProtectThe",
    "slug": "millermedia-protectthe",
    "version": "1.0.0"
}
JSON;
