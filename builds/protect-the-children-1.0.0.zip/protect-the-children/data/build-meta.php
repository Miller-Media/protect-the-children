<?php
return <<<'JSON'
[]
JSON;
